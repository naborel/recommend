https://medium.com/@brruce/use-data-science-to-help-decide-where-to-open-what-type-of-business-426aab144711?sk=3ebe891e37a879eb66350262c5714aff

The project analyzes data from the United States Census Bureau, Foursquare, and ArcGIS to recommend both the location and type
of restaurant to open in a specific region. The example in the notebook analyses the Pacific Northwest region of the US and
recommends several locations within several metros to open recommended restaurant types.

This recommendaton engine can be easily tweaked to work with many other industries.
