https://medium.com/@brruce/australian-rugby-fans-study-claiming-south-african-referee-biased-shown-to-be-false-flag-4b1d22f33fb3

In February 2020, an Australian rugby fan produced a study, claiming to show how South African rugby referees were exhibiting favorable bias towards South African home teams.
The study did not consider how other countries' referees treat South African home teams, an important comparison that needs to made before any conclusion can be drawn.
Yet, the unvetted study was reported by sports journalists from all over the Southern Hemisphere, leading to calls for official inquiries.
The study's conclusions are shown to be unfounded.
